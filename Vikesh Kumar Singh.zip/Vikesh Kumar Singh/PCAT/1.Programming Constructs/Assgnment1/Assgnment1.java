1.Start

2 Take an Integer input from user as num;

3. Check if num%2 =0 or not
4. if num%2=0 then calculate squire of num
       squire=num*num;

5.  if num%2!=0 then calculate cube of num
       cube=num*num*num;

6   end of the program.