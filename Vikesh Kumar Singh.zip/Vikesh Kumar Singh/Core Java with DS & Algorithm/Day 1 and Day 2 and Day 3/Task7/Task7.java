package core_java_assignment;

import java.util.Scanner;

public class Task7 {
	
	 static void bubbleSort(int arr[], int n)
	    {
	        int i, j, temp;
	      
	        for (i = 0; i < n - 1; i++) {
	       
	            for (j = 0; j < n - i - 1; j++) {
	                if (arr[j] > arr[j + 1]) {
	                    temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                }
	            }
	        }
	    }
	
	 
	 
	 public static int linearSearch(int[]arr,int key) {
		 for(int i=0;i<arr.length;i++) {
			 if(arr[i]==key)
				 return i;
		 }
		 return -1;
		 
		 
	 }
	
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of array");
	int n=sc.nextInt();
	int[]arr=new int[n];
	System.out.println("Enter array elements");
	
	for(int i=0;i<n;i++)
		arr[i]=sc.nextInt();
	
	System.out.println("Enter key for searching");
	
	int key=sc.nextInt();
	
	int p= linearSearch(arr,key);
	if(p!=-1)
	System.out.println("After searching index of element is "+p);
	
	else
		System.out.println("Element not found");
	
	bubbleSort(arr, n);
	System.out.println("After sorting array elements is ");
	
	for(int i=0;i<n;i++)	
		System.out.print(arr[i]+" ");
	
}
}
