package core_java_assignment;
import java.util.Scanner;
public class Task1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int first_value=sc.nextInt();
		int Second_value=sc.nextInt();
		System.out.printf("Before swap first value= %d and Second value= %d ",first_value,Second_value);
		first_value=first_value+Second_value;
		Second_value=first_value-Second_value;
		first_value=first_value-Second_value;
		System.out.println();
		System.out.printf("After swap first value= %d and Second value= %d ",first_value,Second_value);
		// TODO Auto-generated method stub

	}

}
