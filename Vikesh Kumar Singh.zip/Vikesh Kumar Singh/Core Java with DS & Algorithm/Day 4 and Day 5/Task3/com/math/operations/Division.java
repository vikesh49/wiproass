package com.math.operations;

public class Division {
    public static double divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Division by zero not allowed.");
        }
        return (double) a / b;
    }
}